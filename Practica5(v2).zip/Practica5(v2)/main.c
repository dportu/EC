//  Estructura de computadores - Practica 5
//  Raúl Alcauter y Daniel Portuondo

//Cronómetro usando el Timer_A con ACLK para mayor precision ya que con SMCLK era más difícil clavar 
//la precisión del cronómetro, el tiempo se muestra mm:ss:cc en el LCD y cada segundo se envía por la UART,
//el control se realiza mediante interrupciones de los botones y el temporizador
//Botón izquierdo para inicio/pausa del cronómetro
//Botón derecho para resetear el cronómetro

#include <msp430.h>
#include <stdio.h>

volatile int centesimas = 0;
volatile int segundos = 0;
volatile int minutos = 0;

volatile int running = 0; // 0 parado, 1 en marcha

volatile int send_uart_flag = 0;

//**********************************
// Configures ACLK to 32 KHz crystal
void config_ACLK_to_32KHz_crystal() {
    // By default, ACLK runs on LFMODCLK at 5MHz/128 = 39 KHz
    // Reroute pins to LFXIN/LFXOUT functionality
    PJSEL1 &= ~BIT4;
    PJSEL0 |= BIT4;
    // Wait until the oscillator fault flags remain cleared
    CSCTL0 = CSKEY; // Unlock CS registers
    do {
        CSCTL5 &= ~LFXTOFFG; // Local fault flag
        SFRIFG1 &= ~OFIFG; // Global fault flag
    } while((CSCTL5 & LFXTOFFG) != 0);
    CSCTL0_H = 0; // Lock CS registers
    return;
}
//**********************************************************
// Initializes the LCD_C module
// *** Source: Function obtained from MSP430FR6989 Sample Code ***
void Initialize_LCD() {
    PJSEL0 = BIT4 | BIT5; // For LFXT
    // Initialize LCD segments 0 - 21; 26 - 43
    LCDCPCTL0 = 0xFFFF;
    LCDCPCTL1 = 0xFC3F;
    LCDCPCTL2 = 0x0FFF;
    // Configure LFXT 32kHz crystal
    CSCTL0_H = CSKEY >> 8; // Unlock CS registers
    CSCTL4 &= ~LFXTOFF; // Enable LFXT
    do {
        CSCTL5 &= ~LFXTOFFG; // Clear LFXT fault flag
        SFRIFG1 &= ~OFIFG;
    }while (SFRIFG1 & OFIFG); // Test oscillator fault flag
    CSCTL0_H = 0; // Lock CS registers
    // Initialize LCD_C
    // ACLK, Divider = 1, Pre-divider = 16; 4-pin MUX
    LCDCCTL0 = LCDDIV__1 | LCDPRE__16 | LCD4MUX | LCDLP;
    // VLCD generated internally,
    // V2-V4 generated internally, v5 to ground
    // Set VLCD voltage to 2.60v
    // Enable charge pump and select internal reference for it
    LCDCVCTL = VLCD_1 | VLCDREF_0 | LCDCPEN;
    LCDCCPCTL = LCDCPCLKSYNC; // Clock synchronization enabled
    LCDCMEMCTL = LCDCLRM; // Clear LCD memory
    //Turn LCD on
    LCDCCTL0 |= LCDON;
    return;
}

//  Timer_A con ACLK para mayor precisión
void init_timer() {
    TA0CTL = TASSEL__ACLK | MC__UP | TACLR;
    TA0CCR0 = 327; // 10 ms (32768 Hz / 100)
    TA0CCTL0 = CCIE;
}

//  Botones (P1.1 y P1.2)
void init_buttons() {
    P1DIR &= ~(BIT1 | BIT2);
    P1REN |= BIT1 | BIT2;      
    P1OUT |= BIT1 | BIT2;      

    P1IE  |= BIT1 | BIT2;      
    P1IES |= BIT1 | BIT2;      
    P1IFG &= ~(BIT1 | BIT2);   
}

const char digits[10][2] = {
    {0xFC,0x28}, // 0
    {0x60,0x20}, // 1
    {0xDB,0x00}, // 2
    {0xF3,0x00}, // 3
    {0x67,0x00}, // 4
    {0xB7,0x00}, // 5
    {0xBF,0x00}, // 6
    {0xE4,0x00}, // 7
    {0xFF,0x00}, // 8
    {0xF7,0x00}  // 9
};

void ShowBuffer(int buffer[]) {

    // minutos
    LCDMEM[9]  = digits[buffer[0]][0];
    LCDMEM[10] = digits[buffer[0]][1];

    LCDMEM[5]  = digits[buffer[1]][0];
    LCDMEM[6]  = digits[buffer[1]][1];

    // segundos
    LCDMEM[3]  = digits[buffer[2]][0];
    LCDMEM[4]  = digits[buffer[2]][1];

    LCDMEM[18] = digits[buffer[3]][0];
    LCDMEM[19] = digits[buffer[3]][1];

    // centesimas
    LCDMEM[14] = digits[buffer[4]][0];
    LCDMEM[15] = digits[buffer[4]][1];

    LCDMEM[7]  = digits[buffer[5]][0];
    LCDMEM[8]  = digits[buffer[5]][1];

    // ":"
    LCDMEM[6]  |= BIT2;
    LCDMEM[19] |= BIT2;
}

void update_LCD() {
    int m1 = minutos / 10;
    int m2 = minutos % 10;

    int s1 = segundos / 10;
    int s2 = segundos % 10;

    int c1 = centesimas / 10;
    int c2 = centesimas % 10;

    int buffer[6] = {
        m1, m2,
        s1, s2,
        c1, c2
    };

    ShowBuffer(buffer);
}

void UART_sendChar(char c) {
    while (!(UCA1IFG & UCTXIFG));
    UCA1TXBUF = c;
}

void UART_sendTime() {
    UART_sendChar('0' + minutos / 10);
    UART_sendChar('0' + minutos % 10);
    UART_sendChar(':');
    UART_sendChar('0' + segundos / 10);
    UART_sendChar('0' + segundos % 10);
    UART_sendChar(':');
    UART_sendChar('0' + centesimas / 10);
    UART_sendChar('0' + centesimas % 10);
    UART_sendChar('\n');
}

void main(void){
    WDTCTL = WDTPW | WDTHOLD;
    PM5CTL0 &= ~LOCKLPM5;

    config_ACLK_to_32KHz_crystal();
    Initialize_LCD();

    init_timer();
    init_buttons();

    P1DIR |= BIT0;   // LED rojo como salida
    P1OUT &= ~BIT0;  

    // UART (P3.4 TX, P3.5 RX)
    P3SEL0 |= BIT4 | BIT5;
    P3SEL1 &= ~(BIT4 | BIT5);

    UCA1CTLW0 = UCSWRST;
    UCA1CTLW0 |= UCSSEL__SMCLK;

    UCA1BR0 = 52;
    UCA1BR1 = 0x00;
    UCA1MCTLW |= UCOS16 | UCBRF_1 | 0x4900;

    UCA1CTLW0 &= ~UCSWRST;

    CSCTL0_H = CSKEY >> 8;
    CSCTL1 = DCOFSEL_3 | DCORSEL;
    CSCTL2 = SELA__LFXTCLK | SELS__DCOCLK | SELM__DCOCLK;
    CSCTL3 = DIVA__1 | DIVS__1 | DIVM__1;
    CSCTL0_H = 0;

    __enable_interrupt();

    __bis_SR_register(LPM0_bits | GIE);

}

//ISR Timer
#pragma vector = TIMER0_A0_VECTOR
__interrupt void TIMER0_A0_ISR(void)
{
    if (!running) return;

    centesimas++;

    if (centesimas == 100) {
        centesimas = 0;
        segundos++;

        send_uart_flag = 1;  // marcar envío
    }

    if (segundos == 60) {
        segundos = 0;
        minutos++;
    }

    update_LCD();
    if (send_uart_flag) {
        UART_sendTime();
        send_uart_flag = 0;
    }
}

//ISR Botones
#pragma vector = PORT1_VECTOR
__interrupt void PORT1_ISR(void)
{
    if (P1IFG & BIT1) {
        running ^= 1; // toggle

        if (running)
            P1OUT |= BIT0;   // LED ON
        else
            P1OUT &= ~BIT0;  // LED OFF

        P1IFG &= ~BIT1;
    }

    if (P1IFG & BIT2) {
        centesimas = 0;
        segundos = 0;
        minutos = 0;
        P1IFG &= ~BIT2;
    }

    update_LCD();
}
