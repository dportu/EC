# FIXED

main.obj: ../main.c
main.obj: /Applications/ti/ccs2000/ccs/ccs_base/msp430/include/msp430.h
main.obj: /Applications/ti/ccs2000/ccs/ccs_base/msp430/include/msp430fr6989.h
main.obj: /Applications/ti/ccs2000/ccs/ccs_base/msp430/include/in430.h
main.obj: /Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h
main.obj: /Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h
main.obj: /Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdio.h
main.obj: /Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h
main.obj: /Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h
main.obj: /Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdarg.h
main.obj: /Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h
main.obj: /Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h
main.obj: /Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h

../main.c:

/Applications/ti/ccs2000/ccs/ccs_base/msp430/include/msp430.h:

/Applications/ti/ccs2000/ccs/ccs_base/msp430/include/msp430fr6989.h:

/Applications/ti/ccs2000/ccs/ccs_base/msp430/include/in430.h:

/Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h:

/Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h:

/Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdio.h:

/Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h:

/Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h:

/Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdarg.h:

/Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h:

/Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h:

/Applications/ti/ccs2000/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h:

