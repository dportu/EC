//  Estructura de computadores - Practica 2 (E/S basica)

#include <msp430.h>

    // El punto 1 se puede tener descomentado junto a cualquier otro punto
    // El programa siempre detiene el watchdog timer y desbloquea los pines, aunque solo se descomente PUNTO_1
//#define PUNTO_1
    // Los siguientes puntos usan un bucle infinito, luego solo se puede ejecutar 1 de ellos
    // Descomentar el que se quiera usar
//#define PUNTO_2
//#define PUNTO_3
#define PUNTO_4
//#define PUNTO_5

#ifdef PUNTO_1
#include <stdio.h>
    // Escribir HOLA MUNDO por consola
void punto1();
#endif

#ifdef PUNTO_2
    // Hacer parpadear el led rojo (P1.0)
void punto2();
#endif

#ifdef PUNTO_3
    // Hacer parpadear el led verde (P9.7)
void punto3();
#endif

#ifdef PUNTO_4
    // Hacer parpadear el led rojo (P1.0) y el led verde (P9.7) simultaneamente
void punto4();
#endif

#ifdef PUNTO_5
    // Implementar el codigo proporcionado en el pdf pero sin usar las funciones de la libreria driverlib
void punto5();
#endif

void main(void) {

// El punto 5 para el watchdog timer y desbloquea los pines por si mismo
#ifndef PUNTO_5
    WDTCTL = WDTPW | WDTHOLD;   // Paramos el watchdog timer poniendo WDTHOLD en 1
    PM5CTL0 &= ~BIT0;           // Ponemos LOCKLPM5 en 0 para habilitar los pines
#endif

    // Punto 1 de la practica
#ifdef PUNTO_1
    punto1();
#endif

    // Punto 2 de la practica
#ifdef PUNTO_2
    punto2();
#endif

    // Punto 3 de la practica
#ifdef PUNTO_3
    punto3();
#endif

    // Punto 4 de la practica
#ifdef PUNTO_4
    punto4();
#endif

    // Punto 5 de la practica
#ifdef PUNTO_5
    punto5();
#endif
}

// FUNCIONES

                // PUNTO 1
#ifdef PUNTO_1
void punto1() {
    // Se imprime HOLA MUNDO por consola y se limpia el buffer de salida
    printf("HOLA MUNDO");
    fflush(stdout);
}
#endif

                // PUNTO 2
#ifdef PUNTO_2
void punto2() {

    // Activamos el pin 0 del puerto 1 como E/S general
    P1SEL0 &= ~BIT0;
    P1SEL1 &= ~BIT0;

    // Establecemos el pin 0 del puerto 1 como salida
    P1DIR |= BIT0;

    // Creamos un bucle infinito
    while (1) {

        // Cambiamos P1.0 de valor
        P1OUT ^= BIT0;

        // Esperamos 30.000 ciclos usando la funcion __delay_cycles(unsigned long), declarada en intrinsics.h
        __delay_cycles(30000);
        // ^ Los intrinsics son como funciones solo que tienen codigo ensamblador en vez de codigo de alto nivel (C en este caso)
    }
}
#endif

                // PUNTO 3
#ifdef PUNTO_3
void punto3() {

    // Activamos el pin 7 del puerto 9 como E/S general
    P9SEL0 &= ~BIT7;
    P9SEL1 &= ~BIT7;

    // Establecemos el pin 0 del puerto 1 como salida
    P9DIR |= BIT7;

    // Creamos un bucle infinito
    while (1) {

        // Cambiamos P9.7 de valor
        P9OUT ^= BIT7;

        // Esperamos 300.000 ciclos usando la funcion __delay_cycles(unsigned long)
        __delay_cycles(300000);
    }
}
#endif

                // PUNTO 4
#ifdef PUNTO_4
void punto4() {

    // Activamos el pin 0 del puerto 1 como E/S general
    P1SEL0 &= ~BIT0;
    P1SEL1 &= ~BIT0;
    // Activamos el pin 7 del puerto 9 como E/S general
    P9SEL0 &= ~BIT7;
    P9SEL1 &= ~BIT7;

    // Establecemos el pin 0 del puerto 1 como salida
    P1DIR |= BIT0;
    // Establecemos el pin 0 del puerto 1 como salida
    P9DIR |= BIT7;

    // Para forzar que los leds se enciendan/apaguen al mismo tiempo,
    // los inicializamos al mismo valor
    P1OUT &= ~BIT0;
    P9OUT &= ~BIT7;
    // ^ P1.0 y P9.7 inicializados a 0

    // Creamos un bucle infinito
    while (1) {

        // Cambiamos P1.0 de valor
        P1OUT ^= BIT0;
        // Cambiamos P9.7 de valor
        P9OUT ^= BIT7;

        // Esperamos cualquier numero de ciclos usando la funcion __delay_cycles(unsigned long)
        __delay_cycles(165000);
    }
}
#endif
                // PUNTO 5
#ifdef PUNTO_5
void punto5() {

    // Se reserva espacio en memoria para un numero entero
    int i;

    // Se detiene el watchdog timer
    WDTCTL = WDTPW | WDTHOLD;

    // Se configura P1.0 como direccion de salida
    P1SEL0 &= ~BIT0;
    P1SEL1 &= ~BIT0;
    P1DIR |= BIT0;

    // Se habilitan los pines
    PM5CTL0 &= ~BIT0;

    // Bucle infinito
    while(1) {

        // Se cambia el valor de P1.0
        P1OUT ^= BIT0;

        // Se espera un tiempo antes de volver al inicio del bucle haciendo uso del entero que creamos al comienzo
        for (i = 10000; i>0; i--);
    }
}
#endif