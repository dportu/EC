# FIXED

main.obj: ../main.c
main.obj: S:/software/electronica/ccstudio-20.2.0/ccs/ccs_base/msp430/include/msp430.h
main.obj: S:/software/electronica/ccstudio-20.2.0/ccs/ccs_base/msp430/include/msp430fr6989.h
main.obj: S:/software/electronica/ccstudio-20.2.0/ccs/ccs_base/msp430/include/in430.h
main.obj: S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h
main.obj: S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h
main.obj: S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdio.h
main.obj: S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h
main.obj: S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h
main.obj: S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdarg.h
main.obj: S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h
main.obj: S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h
main.obj: S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h

../main.c:

S:/software/electronica/ccstudio-20.2.0/ccs/ccs_base/msp430/include/msp430.h:

S:/software/electronica/ccstudio-20.2.0/ccs/ccs_base/msp430/include/msp430fr6989.h:

S:/software/electronica/ccstudio-20.2.0/ccs/ccs_base/msp430/include/in430.h:

S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h:

S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h:

S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdio.h:

S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h:

S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h:

S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdarg.h:

S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h:

S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h:

S:/software/electronica/ccstudio-20.2.0/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h:

