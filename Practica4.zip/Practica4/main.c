//  Estructura de computadores - Practica 3 (E/S basica)

#include <msp430.h>
#include <stdio.h> //?

//#define PUNTO_1
//#define PUNTO_2
#define PUNTO_3



#ifdef PUNTO_1
//  TRANSMISION DEL ABECEDARIO
void punto1();
#endif



#ifdef PUNTO_2
// TRANSMISION DE LETRAS MAYUSCULAS INTRODUCIDAS POR EL TECLADO
void punto2();
#endif



#ifdef PUNTO_3
// UNION DE AMBOS PUNTOS ANTERIORES
void punto3();
#endif



//**********************************
// Configures ACLK to 32 KHz crystal
void config_ACLK_to_32KHz_crystal() {
    // By default, ACLK runs on LFMODCLK at 5MHz/128 = 39 KHz
    // Reroute pins to LFXIN/LFXOUT functionality
    PJSEL1 &= ~BIT4;
    PJSEL0 |= BIT4;
    // Wait until the oscillator fault flags remain cleared
    CSCTL0 = CSKEY; // Unlock CS registers
    do {
        CSCTL5 &= ~LFXTOFFG; // Local fault flag
        SFRIFG1 &= ~OFIFG; // Global fault flag
    } while((CSCTL5 & LFXTOFFG) != 0);
    CSCTL0_H = 0; // Lock CS registers
    return;
}
//**********************************************************
// Initializes the LCD_C module
// *** Source: Function obtained from MSP430FR6989 Sample Code ***
void Initialize_LCD() {
    PJSEL0 = BIT4 | BIT5; // For LFXT
    // Initialize LCD segments 0 - 21; 26 - 43
    LCDCPCTL0 = 0xFFFF;
    LCDCPCTL1 = 0xFC3F;
    LCDCPCTL2 = 0x0FFF;
    // Configure LFXT 32kHz crystal
    CSCTL0_H = CSKEY >> 8; // Unlock CS registers
    CSCTL4 &= ~LFXTOFF; // Enable LFXT
    do {
        CSCTL5 &= ~LFXTOFFG; // Clear LFXT fault flag
        SFRIFG1 &= ~OFIFG;
    }while (SFRIFG1 & OFIFG); // Test oscillator fault flag
    CSCTL0_H = 0; // Lock CS registers
    // Initialize LCD_C
    // ACLK, Divider = 1, Pre-divider = 16; 4-pin MUX
    LCDCCTL0 = LCDDIV__1 | LCDPRE__16 | LCD4MUX | LCDLP;
    // VLCD generated internally,
    // V2-V4 generated internally, v5 to ground
    // Set VLCD voltage to 2.60v
    // Enable charge pump and select internal reference for it
    LCDCVCTL = VLCD_1 | VLCDREF_0 | LCDCPEN;
    LCDCCPCTL = LCDCPCLKSYNC; // Clock synchronization enabled
    LCDCMEMCTL = LCDCLRM; // Clear LCD memory
    //Turn LCD on
    LCDCCTL0 |= LCDON;
    return;
}

const char alphabetBig[26][2] =
{
    {0xEF, 0x00}, /* "A" LCD segments a+b+c+e+f+g+m */
    {0xF1, 0x50}, /* "B" */
    {0x9C, 0x00}, /* "C" */
    {0xF0, 0x50}, /* "D" */
    {0x9F, 0x00}, /* "E" */
    {0x8F, 0x00}, /* "F" */
    {0xBD, 0x00}, /* "G" */
    {0x6F, 0x00}, /* "H" */
    {0x90, 0x50}, /* "I" */
    {0x78, 0x00}, /* "J" */
    {0x0E, 0x22}, /* "K" */
    {0x1C, 0x00}, /* "L" */
    {0x6C, 0xA0}, /* "M" */
    {0x6C, 0x82}, /* "N" */
    {0xFC, 0x00}, /* "O" */
    {0xCF, 0x00}, /* "P" */
    {0xFC, 0x02}, /* "Q" */
    {0xCF, 0x02}, /* "R" */
    {0xB7, 0x00}, /* "S" */
    {0x80, 0x50}, /* "T" */
    {0x7C, 0x00}, /* "U" */
    {0x0C, 0x28}, /* "V" */
    {0x6C, 0x0A}, /* "W" */
    {0x00, 0xAA}, /* "X" */
    {0x00, 0xB0}, /* "Y" */
    {0x90, 0x28} /* "Z" */
};

void ShowBuffer(int buffer[]) {
    LCDMEM[9] = alphabetBig[(buffer[5])-65][0];
    LCDMEM[10] = alphabetBig[(buffer[5])-65][1];
    LCDMEM[5] = alphabetBig[(buffer[4])-65][0];
    LCDMEM[6] = alphabetBig[(buffer[4])-65][1];
    LCDMEM[3] = alphabetBig[(buffer[3])-65][0];
    LCDMEM[4] = alphabetBig[(buffer[3])-65][1];
    LCDMEM[18] = alphabetBig[(buffer[2])-65][0];
    LCDMEM[19] = alphabetBig[(buffer[2])-65][1];
    LCDMEM[14] = alphabetBig[(buffer[1])-65][0];
    LCDMEM[15] = alphabetBig[(buffer[1])-65][1];
    LCDMEM[7] = alphabetBig[(buffer[0])-65][0];
    LCDMEM[8] = alphabetBig[(buffer[0])-65][1];
}




void main(void) {
    WDTCTL = WDTPW | WDTHOLD;
    PM5CTL0 &= ~LOCKLPM5;

    // Configurar pines P3.4 (TX) y P3.5 (RX) para UART
    P3SEL0 |= BIT4 | BIT5;
    P3SEL1 &= ~(BIT4 | BIT5);

    // Configuracion comun a todos los apartados
    CSCTL0_H = CSKEY >> 8; // Unlock clock registers
    CSCTL1 = DCOFSEL_3 | DCORSEL; // Set DCO to 8MHz
    CSCTL2 = SELA__VLOCLK | SELS__DCOCLK | SELM__DCOCLK;
    CSCTL3 = DIVA__1 | DIVS__1 | DIVM__1; // Set all dividers
    CSCTL0_H = 0; // Lock CS registers

    // Configure USCI_A1 for UART mode
    UCA1CTLW0 = UCSWRST; // Put eUSCI in reset
    UCA1CTLW0 |= UCSSEL__SMCLK; // CLK = SMCLK
    // Baud Rate calculation
    // 8000000/(16*9600) = 52.083
    // Fractional portion = 0.083
    // User Guide Table 21-4: UCBRSx = 0x04
    // UCBRFx = int ( (52.083-52)*16) = 1
    UCA1BR0 = 52; // 8000000/16/9600
    UCA1BR1 = 0x00;
    UCA1MCTLW |= UCOS16 | UCBRF_1 | 0x4900;
    UCA1CTLW0 &= ~UCSWRST; // Initialize eUSCI


    // Punto 1 de la practica
#ifdef PUNTO_1
    punto1();
#endif

    // Punto 2 de la practica
#ifdef PUNTO_2
    punto2();
#endif

    // Punto 3 de la practica
#ifdef PUNTO_3
    punto3();
#endif
}






// PUNTO 1
#ifdef PUNTO_1
void punto1() {
    // Habilitar interrupción de transmisión
    UCA1IE |= UCTXIE;

    // Timer con SMCLK (8MHz), ~0.5s
    // 8000000 / 8 = 1000000, con ID__8
    // CCR0 = 500000 para 0.5s
    TA1CTL   = TASSEL__SMCLK | ID__8 | MC__UP | TACLR;
    TA1CCR0  = 50000;   // 8MHz/8/50000 = ~0.5s
    TA1CCTL0 = CCIE;


    __bis_SR_register(LPM0_bits | GIE);
}
#endif


// PUNTO 2
#ifdef PUNTO_2
void punto2() {
    Initialize_LCD();

    // Habilitar interrupción de recepción
    UCA1IE |= UCRXIE;

    __bis_SR_register(LPM0_bits | GIE);
}
#endif


// PUNTO 3
#ifdef PUNTO_3
void punto3() {
     // Habilitar interrupción de transmisión
    UCA1IE |= UCTXIE;

    // Timer con SMCLK (8MHz), ~0.5s
    // 8000000 / 8 = 1000000, con ID__8
    // CCR0 = 500000 para 0.5s
    TA1CTL   = TASSEL__SMCLK | ID__8 | MC__UP | TACLR;
    TA1CCR0  = 50000;   // 8MHz/8/50000 = ~0.5s
    TA1CCTL0 = CCIE;

    Initialize_LCD();

    // Habilitar interrupción de recepción
    UCA1IE |= UCRXIE;

    __bis_SR_register(LPM0_bits | GIE);
}
#endif




volatile int tx_ready = 1; // booleano de tx lista
volatile char letra = 'A';
volatile int buffer[6];
volatile int buf_idx = 0;
# pragma vector = USCI_A1_VECTOR
__interrupt void USCI_A1_ISR ( void )
{
    if (UCA1IFG & UCTXIFG) {        // interrupción de transmision
        tx_ready = 1;               // marcar UART lista
        UCA1IFG &= ~UCTXIFG;        // borrar flag TX
    }
    if (UCA1IFG & UCRXIFG) {
        char recibido = UCA1RXBUF;  // leer (borra el flag solo)

        // solo procesar letras mayúsculas
        if (recibido >= 'A' && recibido <= 'Z') {
            buffer[buf_idx] = recibido;
            buf_idx = (buf_idx + 1) % 6;  // avance circular
            ShowBuffer(buffer);
        }
    }
}
// Rutina de interrupci´on de TIMER1_A0
# pragma vector = TIMER1_A0_VECTOR
__interrupt void TIMER1_A0_ISR ( void ) {
    // si el booleano de transmisi´on est´a listo
    // enviar dato a la UART
    // borrar booleano de transmisi´on
    // resto de funci´on de int. timer

    if (tx_ready) {
        UCA1TXBUF = letra;          // enviar letra actual
        letra++;                    // avanzar al siguiente carácter
        if (letra > 'Z')  {
            letra = 'A';  // volver a 'A' al llegar al final
        }
        tx_ready = 0;               // limpiar booleano
    }
}


