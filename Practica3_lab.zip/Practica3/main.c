//  Estructura de computadores - Practica 3 (E/S basica)

#include <msp430.h>
#include <stdio.h> //?

//#define PUNTO_1
//#define PUNTO_2
//#define PUNTO_3
#define PUNTO_4



#ifdef PUNTO_1
//  ENCENDIDO/APAGADO DEL LED ROJO POR POLLING SOBRE SW P1.1
void punto1();
#endif



#ifdef PUNTO_2
// ENCENDIDO/APAGADO DEL LED ROJO POR INTERRUPCION TRIGGEREADA POR SW 1.1
void punto2();
#endif



#ifdef PUNTO_3
// CONMUTACION AUTOMATICA DEL LED ROJO POR TIMER E INTERRUPCION
void punto3();
#endif



#ifdef PUNTO_4
// PUNTO 3 PERO CON PAUSA Y RESUME CON LOS SW
void punto4();
void config_ACLK_to_32KHz_crystal();
void Initialize_LCD();
const unsigned char LCD_Num[10] = {0xFC, 0x60, 0xDB, 0xF3, 0x67, 0xB7, 0xBF, 0xE0, 0xFF, 0xE7};
    //***************function that displays any 16-bit unsigned integer************
    inline void display_num_lcd(unsigned int n){
    int i = 0;
    do {
        unsigned int digit = n % 10;
        switch(i){
            case 0: LCDM8 = LCD_Num[digit]; break; //first digit
            case 1: LCDM15 = LCD_Num[digit]; break; //second digit
            case 2: LCDM19 = LCD_Num[digit]; break; //third digit
            case 3: LCDM4 = LCD_Num[digit]; break; //fourth digit
            case 4: LCDM6 = LCD_Num[digit]; break; //fifth digit
        }
        n /= 10;
        i++;
    } while(i < 5);
}

#endif







void main(void) {

    // Punto 1 de la practica
#ifdef PUNTO_1
    punto1();
#endif

    // Punto 2 de la practica
#ifdef PUNTO_2
    punto2();
#endif

    // Punto 3 de la practica
#ifdef PUNTO_3
    punto3();
#endif

    // Punto 4 de la practica
#ifdef PUNTO_4
    punto4();
#endif

    // Punto 5 de la practica
#ifdef PUNTO_5
    punto5();
#endif
}






// PUNTO 1
#ifdef PUNTO_1
void punto1() {
    //disable watchdog
    WDTCTL = WDTPW | WDTHOLD;
    //disable high impeadance on I/O
    PM5CTL0 &= ~LOCKLPM5;
    P1DIR = BIT0; //set P1.0 as output, rest as inputs
    P1REN = BIT1; //enable pull on P1.1, rest disabled
    P1OUT = BIT1; //set pull-up on P1.1
    while(1) {
        if (P1IN & BIT1) { //if P1.1 is not pushed (1 is default since we use pullup)
            P1OUT |= BIT0; //write 1 on P1.0
        }
        else {
            P1OUT &= ~BIT0; //write 0 on P1.0
        }
    }
}
#endif




// PUNTO 2
#ifdef PUNTO_2
void punto2() {
    //disable watchdog
    WDTCTL = WDTPW | WDTHOLD;
    //disable high impeadance on I/O
    PM5CTL0 &= ~LOCKLPM5;
    P1DIR = BIT0; //set P1.0 as output, rest as inputs
    P1REN = BIT1; //enable pull on P1.1, rest disabled
    P1OUT = BIT1; //set pull-up on P1.1
    P1IE |= BIT1; //P1.1 IRQ enabled
    P1IES |= BIT1; //P1.1 Falling edge
    P1IFG &= ~BIT1; //P1.1 clear pending interrupts
    __bis_SR_register(LPM4_bits | GIE); //Enter LMP4 mode (sleep)
}

//  Port 1 ISR
#pragma vector=PORT1_VECTOR
__interrupt void Port_1(void) {
    P1OUT ^= BIT0; //   Toggle P1.0
    P1IFG &= ~BIT1; //  P1.1 clear pending interrupts
}

#endif





// PUNTO 3
#ifdef PUNTO_3
void punto3() {
    // Inicialización básica
    WDTCTL = WDTPW | WDTHOLD;
    PM5CTL0 &= ~LOCKLPM5;
    P1DIR |= BIT0;  // LED rojo como salida

    // Configuracion TIMER_A:
    // TimerA1, ACLK/1, modo up, reinicia TACLR
    TA1CTL = TASSEL__ACLK | ID__1 | MC__UP | TACLR;
    // ACLK tiene una frecuencia de 32768 Hz
    // Carga cuenta en TA1CCR0 0.1seg TA1CCR=(0,1*32768)-1
    // se dispara aprox. cada 0.1s
    TA1CCR0 = 3276;
    TA1CCTL0 = CCIE; // Habilita interrupci´on (bit CCTIMER1_A0IE) en TIMER1_A0
    
    __bis_SR_register(LPM4_bits | GIE); //Enter LMP4 mode (sleep)
}

// Rutina de interrupcion de TIMER1_A0
#pragma vector=TIMER1_A0_VECTOR
__interrupt void TIMER1_A0_ISR(void){
    P1OUT ^= BIT0; // conmuta LED en P1.0
    
}
#endif


#ifdef PUNTO_4
//volatile unsigned char timer_running = 1; // estado del timer
volatile unsigned int contador = 0;
volatile unsigned int modo_parpadeo = 0; // 0 -> no parpadeo | 1 -> parpadeo rapido
volatile unsigned int count = 0;

void punto4() {
    WDTCTL = WDTPW | WDTHOLD;
    PM5CTL0 &= ~LOCKLPM5;

    // LEDs rojo y verde como salida
    P1DIR |= BIT0;
    P9DIR |= BIT7;

    // Boton 1: P1.1 - Pausar/Continuar
    P1REN |= BIT1;
    P1OUT |= BIT1;          // pull-up
    P1IE  |= BIT1;
    P1IES |= BIT1;          // flanco bajada
    P1IFG &= ~BIT1;

    // Boton 2: P1.2 - Reiniciar
    P1REN |= BIT2;
    P1OUT |= BIT2;          // pull-up
    P1IE  |= BIT2;
    P1IES |= BIT2;          // flanco bajada
    P1IFG &= ~BIT2;

    // Primero ACLK, luego LCD
    config_ACLK_to_32KHz_crystal();
    Initialize_LCD();

    // Timer: ACLK/1, modo up, ~0.1s
    TA1CTL   = TASSEL__ACLK | ID__1 | MC__UP | TACLR;
    TA1CCR0  = 3276;
    TA1CCTL0 = CCIE;

    __bis_SR_register(LPM0_bits | GIE); // LPM0 (ACLK sigue activo)
}

// ISR del timer: conmuta el LED
#pragma vector=TIMER1_A0_VECTOR
__interrupt void TIMER1_A0_ISR(void) {
    if (modo_parpadeo == 0) { // no parpadeo
        P1OUT &= ~BIT0;
        P9OUT &= ~BIT7;
    }
    else if(modo_parpadeo == 1) { // parpadeo rapido
        P1OUT ^= BIT0;
    }
    else if(modo_parpadeo == 3){ // luz verde un segundo
        P1OUT &= ~BIT0; // luz roja apagada
        P9OUT |= BIT7; // luz verde encendida
    }
    else { // parpadeo largo
        if (count%10 == 0) {
            P1OUT ^= BIT0;
        }
    }
    

    switch(modo_parpadeo) {
        case 0: // no parpadeo
            if(contador%50 == 0) {
                //sCount++;
                modo_parpadeo = 1;
                count = 0;
            }
            break; 
        case 1: // parpadeo corto
            if (count == 3) {
                modo_parpadeo = 0;
                count = 0;
            }
            else {
                count++;
            }
            break;
        case 2: // parpadeo largo continuo
            count++;
            break;
        case 3: // luz verde encendida y roja apagada
            if(count == 10) {
                count = 0;
                modo_parpadeo = 0;
            }
            else {
                count++;
            }
            break;
    }


    contador++;
    
    display_num_lcd(contador);
}

// ISR de los botones
#pragma vector=PORT1_VECTOR
__interrupt void Port_1(void) {
    if (P1IFG & BIT1) {             // Boton 1: Parpadeos largos
        modo_parpadeo = 2;
        count = 0;
        P1IFG &= ~BIT1; //  Desactivamos el flag de interrupcion pendiente 
    }
    else if (P1IFG & BIT2) {        // Boton 2: luz verde 1s después modo normal, reseteo contador
        modo_parpadeo = 3;
        count = 0;
        contador = 0;
        P1IFG &= ~BIT2; //  Desactivamos el flag de interrupcion pendiente
    }
}




//**********************************
// Configures ACLK to 32 KHz crystal
void config_ACLK_to_32KHz_crystal() {
    // By default, ACLK runs on LFMODCLK at 5MHz/128 = 39 KHz
    // Reroute pins to LFXIN/LFXOUT functionality
    PJSEL1 &= ~BIT4;
    PJSEL0 |= BIT4;
    // Wait until the oscillator fault flags remain cleared
    CSCTL0 = CSKEY; // Unlock CS registers
    do {
        CSCTL5 &= ~LFXTOFFG; // Local fault flag
        SFRIFG1 &= ~OFIFG; // Global fault flag
    } while((CSCTL5 & LFXTOFFG) != 0);
    CSCTL0_H = 0; // Lock CS registers
    return;
}
//**********************************************************
// Initializes the LCD_C module
// *** Source: Function obtained from MSP430FR6989 Sample Code ***
void Initialize_LCD() {
    PJSEL0 = BIT4 | BIT5; // For LFXT
    // Initialize LCD segments 0 - 21; 26 - 43
    LCDCPCTL0 = 0xFFFF;
    LCDCPCTL1 = 0xFC3F;
    LCDCPCTL2 = 0x0FFF;
    // Configure LFXT 32kHz crystal
    CSCTL0_H = CSKEY >> 8; // Unlock CS registers
    CSCTL4 &= ~LFXTOFF; // Enable LFXT
    do {
        CSCTL5 &= ~LFXTOFFG; // Clear LFXT fault flag
        SFRIFG1 &= ~OFIFG;
    }while (SFRIFG1 & OFIFG); // Test oscillator fault flag
    CSCTL0_H = 0; // Lock CS registers
    // Initialize LCD_C
    // ACLK, Divider = 1, Pre-divider = 16; 4-pin MUX
    LCDCCTL0 = LCDDIV__1 | LCDPRE__16 | LCD4MUX | LCDLP;
    // VLCD generated internally,
    // V2-V4 generated internally, v5 to ground
    // Set VLCD voltage to 2.60v
    // Enable charge pump and select internal reference for it
    LCDCVCTL = VLCD_1 | VLCDREF_0 | LCDCPEN;
    LCDCCPCTL = LCDCPCLKSYNC; // Clock synchronization enabled
    LCDCMEMCTL = LCDCLRM; // Clear LCD memory
    //Turn LCD on
    LCDCCTL0 |= LCDON;
    return;
}
#endif
